# YuuZPrime Android

Full React Native / Expo source based on Valora Film. UI and player implementation retained. Independent modifications: YuuZGilakPrompt. Original project: Valora / Zyxone. License: Apache-2.0 (see LICENSE and NOTICE-YUUZPRIME.md).

## GitHub Actions

Upload `YuuZPrime-Valora-Full.zip` to your repository root and copy `build-yuuzprime-valora.yml` to `.github/workflows/build-apk.yml`. The workflow accepts this exact ZIP or an extracted project. It builds Android using Node 22, JDK 17, Android SDK 36 and the Expo-generated Gradle wrapper. APK is signed using the development/debug signing configuration, for testing only. Optional repository variable `TMDB_API_KEY` is for your own authorized TMDB API key; it is bundled into the app.

The app does not host media. Use only media you are authorized to access. Third-party source availability is not guaranteed. Original upstream documentation: README-UPSTREAM.md.

Build results: Actions > Build YuuZPrime APK > Artifacts. Manual runs can optionally publish a GitHub Release.

## 1.0.4
Katalog TMDB (Film, Serial, Anime), pencarian metadata dengan pagination, credit dan atribusi. Katalog metadata bukan jaminan video tersedia. Workflow V6 dipertahankan.
