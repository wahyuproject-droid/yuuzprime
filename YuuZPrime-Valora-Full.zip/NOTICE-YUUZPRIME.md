# YuuZPrime

Modified from the user-supplied Valora Film source distribution (Valora / Zyxone; upstream https://github.com/B7ByteMe/valorafilm).

Rebranding and CI customization: YuuZGilakPrompt.

The original Apache License 2.0 remains in LICENSE. Original attribution and third-party notices remain applicable. The modified files include app configuration, project metadata, UI branding, settings, theme defaults, Android asset images, and GitHub Actions build tooling. This is an independent modification and not an official upstream release.
