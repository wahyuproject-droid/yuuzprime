package com.yuuzprime.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.io.*;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private FrameLayout root;
    private View full;
    private WebChromeClient.CustomViewCallback fullCallback;
    private static final String HOST = "appassets.androidplatform.net";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this); web = new WebView(this); root.addView(web, new FrameLayout.LayoutParams(-1,-1)); setContentView(root);
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); s.setMediaPlaybackRequiresUserGesture(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView w, WebResourceRequest req) {
                Uri u=req.getUrl(); if(!"https".equals(u.getScheme()) || !HOST.equals(u.getHost())) return null;
                String path=u.getPath(); if(path==null) return null;
                String file=path.equals("/")?"index.html":path.substring(1);
                if(!file.matches("[a-zA-Z0-9_.-]+")) return null;
                String mime=file.endsWith(".js")?"application/javascript":file.endsWith(".css")?"text/css":file.endsWith(".png")?"image/png":"text/html";
                try { return new WebResourceResponse(mime, file.endsWith(".png")?null:"UTF-8",getAssets().open(file)); } catch(IOException e){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
            }
            @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest req) {
                Uri u=req.getUrl(); if(HOST.equals(u.getHost()) && "https".equals(u.getScheme())) return false;
                if(req.isForMainFrame() && req.hasGesture() && "https".equals(u.getScheme())) { try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch(Exception ignored){} }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(chooser!=null) chooser.onReceiveValue(null); chooser=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("video/*");
                try { startActivityForResult(i,42); } catch(Exception e){chooser.onReceiveValue(null); chooser=null;} return true;
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback){
                if(full!=null){callback.onCustomViewHidden();return;} full=view; fullCallback=callback; web.setVisibility(View.GONE);root.addView(view,new FrameLayout.LayoutParams(-1,-1));getWindow().getDecorView().setSystemUiVisibility(5894);
            }
            @Override public void onHideCustomView(){hideFull();}
        });
        web.loadUrl("https://"+HOST+"/index.html");
    }
    private void hideFull(){if(full==null)return;root.removeView(full);full=null;web.setVisibility(View.VISIBLE);getWindow().getDecorView().setSystemUiVisibility(0);if(fullCallback!=null){fullCallback.onCustomViewHidden();fullCallback=null;}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==42&&chooser!=null){chooser.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);chooser=null;}}
    @Override public void onBackPressed(){if(full!=null)hideFull();else if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(chooser!=null){chooser.onReceiveValue(null);chooser=null;}if(web!=null){web.stopLoading();web.destroy();}super.onDestroy();}
}
