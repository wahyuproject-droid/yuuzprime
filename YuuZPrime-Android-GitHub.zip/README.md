# YuuZPrime Android

Adaptasi Android 1.0.0, branding YuuZGilakPrompt berdasarkan modifikasi Streambert oleh truelockmc. Lisensi GPL-3.0 dan atribusi logo dipertahankan. Bukan konversi Electron 1:1. Aplikasi memiliki katalog metadata TMDB, tautan opsi menonton resmi, dan pemutar file/URL video yang diizinkan. Tidak menyertakan penyedia stream desktop, download dari penyedia, atau fitur Discord RPC.

## GitHub (tanpa PC build)
1. Ekstrak ZIP. Unggah **isi** folder ke root repository GitHub, termasuk folder tersembunyi `.github` (gunakan Git atau buat file workflow melalui GitHub jika browser melewatkan folder ini).
2. Pastikan `settings.gradle`, `app/`, dan `.github/workflows/build-apk.yml` berada di root repository.
3. Push ke `main`/`master` atau buka Actions > Build YuuZPrime APK > Run workflow.
4. Setelah build sukses, unduh `YuuZPrime-APK` dari Artifacts (ekstrak ZIP untuk APK) atau `YuuZPrime.apk` dari Releases. Jika organisasi membatasi hak tulis token, gunakan Artifacts.

APK adalah debug-signed untuk pengujian pribadi; bukan paket Play Store. Kunci debug runner bisa berubah antar-build sehingga update mungkin perlu uninstall dulu. Untuk distribusi stabil, gunakan signing key milik sendiri. Min Android 7.0 (API 24), compile SDK 35, JDK 17, Gradle 8.9. Katalog memerlukan token TMDB pribadi. Gunakan video yang sah. Build Android belum dijalankan pada lingkungan penyusunan ini.
