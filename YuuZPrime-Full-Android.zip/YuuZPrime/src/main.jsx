import React from "react";
import ReactDOM from "react-dom/client";
import "./i18n";
import App from "./App";
import "./styles/global.css";
import "./styles/android.css";
if (import.meta.env.MODE === "android") document.documentElement.dataset.yuuzAndroid = "1";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
