import {useState,useEffect} from "react";
export default function AndroidPlayer(){
  const [item,setItem]=useState(null),[file,setFile]=useState(null),[url,setUrl]=useState("");
  useEffect(()=>{const open=e=>{setFile(null);setItem(e.detail||{});};window.addEventListener("yuuz:local-player",open);return()=>window.removeEventListener("yuuz:local-player",open);},[]);
  useEffect(()=>{if(!file){setUrl("");return;}const u=URL.createObjectURL(file);setUrl(u);return()=>URL.revokeObjectURL(u);},[file]);
  if(!item)return null;
  return <div className="yp-mobile-player" role="dialog" aria-modal="true" aria-label="Pemutar video"><div className="yp-mobile-player-card"><button className="btn btn-secondary" onClick={()=>{setItem(null);setFile(null);}}>Tutup</button><h2>{item.title||"Video lokal"}</h2><p>Pilih file video milikmu. Katalog film tidak menyediakan file film penuh.</p><input type="file" accept="video/*" onChange={e=>setFile(e.target.files?.[0]||null)}/>{url&&<video key={url} src={url} controls playsInline style={{width:"100%",maxHeight:"55vh"}}/>}</div></div>;
}
