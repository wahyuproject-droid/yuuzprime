# YuuZPrime

Branding, UI modifications and Android adaptation: YuuZGilakPrompt, 27 November 2026.

Original project: Streambert by truelockmc and contributors. Original copyright, attribution and GPL-3.0 license remain in effect, including for distributed modified versions. See LICENSE and UPSTREAM-README.md.

The Android edition does not port Electron IPC, third-party full-film stream providers, desktop downloader, or desktop subtitle management. It uses the original React catalog and local video playback.
