# YuuZPrime — Desktop + Android

Full Streambert-derived source, original React pages and original screenshots retained. UI, branding and Android modifications by **YuuZGilakPrompt**. Original project by truelockmc and contributors, GPL-3.0. See LICENSE, NOTICE-YuuZPrime.md and UPSTREAM-README.md.

## Android GitHub Actions

Upload `YuuZPrime-Full-Android.zip` and `build-apk-full.yml` at `.github/workflows/build-apk.yml` to your GitHub repository. The workflow extracts the ZIP, locates the full React/Android project, installs locked npm dependencies, builds Vite with Android mode, builds the APK with Java 17 / Gradle 8.9 / Android SDK 35 and uploads the APK. Delete the old small ZIP and obsolete build workflows first. The output is a debug APK for testing.

Android uses the original React catalog (TMDB token required), original library and search, detail pages, settings and original assets. Mobile navigation and local file player are added. Electron-specific features and third-party full-film playback are not ported. Trailer opens in the browser. The TMDB token is saved in the app's private WebView local storage rather than Electron safeStorage.

## Desktop

Node.js 22.12+; `npm ci`, then `npm start`. Windows build: `npm run dist:win`. Original Electron files are retained. Use media/services you have permission to access.

Build and device runtime require testing.
